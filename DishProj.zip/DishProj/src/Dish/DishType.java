package Dish;

public enum DishType {
	Meat,FISH,OTHER
}
